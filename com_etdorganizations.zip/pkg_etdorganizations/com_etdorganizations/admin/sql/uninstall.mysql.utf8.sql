DROP TABLE IF EXISTS `#__etdorganizations_organizations`;
DROP TABLE IF EXISTS `#__etdorganizations_organization_contacts`;